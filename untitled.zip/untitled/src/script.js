function showEnvelope() {

    document.getElementById("intro").style.display = "none";

    document.getElementById("surprise").style.display = "flex";

}


function openLetter() {

    let envelope =
        document.getElementById("envelope");

    envelope.classList.add("open");

    document.getElementById("openButton")
        .style.display = "none";


    setTimeout(function() {

        document.getElementById("message")
            .style.display = "block";

        document.getElementById("message")
            .scrollIntoView({
                behavior: "smooth"
            });

    }, 1500);

}